USE Wistful
GO

CREATE TABLE AdoShopping(
	ShopName nvarchar(255),
	ShopDate date,
	Spending decimal(10,2)
)
GO

SELECT * FROM AdoShopping